package com.example.divya.videoview;

import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.VideoView;
import android.widget.MediaController;

public class MainActivity extends AppCompatActivity {
      VideoView videoview;
      MediaController mediac;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        videoview=(VideoView)findViewById(R.id.videoView);
        mediac=new MediaController(this);
        videoview.setVideoURI(Uri.parse("android.resource://"+getPackageName()+"/" + R.raw.video));
        videoview.setMediaController(mediac);
       videoview.start();
       videoview.pause();

    }
}
